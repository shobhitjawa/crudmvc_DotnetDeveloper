﻿using crudmvc.Models;
using crudmvc.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace crudmvc.Controllers
{
    public class StudentController : Controller
    {
        private IStudentRepository _studentRepository;

        public StudentController(IStudentRepository studentRepository)
        {

            _studentRepository = studentRepository;
        }
        public JsonResult GetalltheStudents()
        {
            return Json(new { data = _studentRepository.GetStudents().ToList() }); ;
        }
        public IActionResult Index()
        {
            var students = _studentRepository.GetStudents();
            return View(students);
        }
        public ActionResult Create()
        {
            return View(new Student());
        }
        [HttpPost]
        public ActionResult Create(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _studentRepository.InsertStudent(student);
                    _studentRepository.Save();
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {
                ModelState.AddModelError("", "Unable to save changes. " +
                  "Try again, and if the problem persists see your system administrator.");
            }
            return View(student);
        }

        public ActionResult Edit(int id)
        {
            Student student = _studentRepository.GetStudentByID(id);
            return View(student);
        }
        [HttpPost]
        public ActionResult Edit(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _studentRepository.UpdateStudent(student);
                    _studentRepository.Save();
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again.");
            }
            return View(student);
        }
        public ActionResult Delete(int id)
        {
            Student student = _studentRepository.GetStudentByID(id);
            return View(student);
        }
        [HttpPost]
        public ActionResult DeleteConfirmed(Student student1)
        {
            var a = student1.Id;
            Student student = _studentRepository.GetStudentByID(a);
            _studentRepository.DeleteStudent(a);
            _studentRepository.Save();
            return RedirectToAction("Index");
        }

    }
}
